# Assets
> ## CC0 Resorces sorted by quality:
> 	awesome list of free to use public domain CC0 licensed assets from across the internet
> 	CC0 = No copyright, 100% free to use for any purpose even commercially. [Learn more](https://creativecommons.org/publicdomain/zero/1.0/deed)
> - https://polyhaven.com/
> - https://quixel.com/plugins/
> - https://www.poliigon.com/search/free
> - https://www.3dassets.one/#order=latest
> - https://rawcatalog.com/library/atlases/
> - https://www.thebasemesh.com/
> ## Textures / Reference
> - https://www.sharetextures.com/
> - https://texture.ninja/
> - https://unsplash.com/
> - https://www.cgbookcase.com/textures
> - https://texturebox.com/free
> ## Fonts
> - https://www.dafont.com/
> - https://fonts.adobe.com/
> ## Sound:
> - https://freesound.org/
> - https://gdc.sonniss.com/
> - https://studio.youtube.com/channel/UCHk6p2-7MaJssmX9NzaXtzw/music
> ## IES Light Profiles
> - https://ieslibrary.com/
