# Flow Map painter:
- https://teckartist.com/?page_id=107
	
	
# A good RenderFarm:
- https://www.foxrenderfarm.com/

# Color Palette List
- https://lospec.com/palette-list

# Sending Files
- https://wetransfer.com/
  
# Highly Important
- https://en.wikipedia.org/wiki/Corn_dog
