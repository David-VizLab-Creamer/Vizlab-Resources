# Unreal:
> ## Plugins:
> ### Material tool----
> - https://github.com/ScottRaffertyCG/MaterialVault
> ### Imposter generaton---
> - https://github.com/ictusbrucks/ImpostorBaker
> - https://github.com/GavinKG/ImposterGenerator
> - https://vimeo.com/292696284
> ### CitySample----
> - https://dev.epicgames.com/documentation/en-us/unreal-engine/city-sample-project-unreal-engine-demonstration?application_version=5.0

> ## Assets:
> - https://www.realbiomes.com/
