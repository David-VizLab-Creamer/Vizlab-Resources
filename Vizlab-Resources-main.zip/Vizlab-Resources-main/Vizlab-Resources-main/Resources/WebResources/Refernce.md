# Reference
> ## Materials Info
> - https://physicallybased.info/
> - https://spectraldb.com/
> - https://midimagic.sgc-hosting.com/huvision.htm
> - https://www.giangrandi.org/optics/eye/eye.shtml
> ## Anatomy and Form
> - https://lluisv.itch.io/z-anatomy
> - https://www.artstation.com/georgezaky108
> - https://www.artstation.com/anatomy4sculptors
> ## Character Sculpting
> - https://www.artstation.com/donchuan3d
> - https://www.artstation.com/follygon
> - https://www.artstation.com/tlsalswjddd
> - https://www.artstation.com/castroanimationstudio
> - https://www.artstation.com/geosis093
> - https://www.artstation.com/tycane3d
> - https://www.artstation.com/ayalaoscar
> - https://www.artstation.com/fabiopaiva
> ## Topology
> - https://www.artstation.com/alexmougenot
> - https://www.artstation.com/artwork/vJKaRd
> - https://www.artstation.com/artwork/Jre5Ea (Environment Topology)
> - https://www.artstation.com/artwork/1N8gD2
> ## Art of Animation
> - https://characterdesignreferences.com/art-of-animation
> - https://characterdesignreferences.com/visual-library
> - https://characterdesignreferences.com/artist-of-the-week
> - https://livlily.blogspot.com/2010/11/model-sheets-production-drawings.html
> - https://walk-cycle-depot.blogspot.com/
> - https://sevencamels.blogspot.com/?view=flipcard
> - https://the12principles.tumblr.com/
> - https://www.youtube.com/c/AlejandroLuisGarcia
> - https://animationresources.org/
> - https://felixcolgrave.myportfolio.com/
> - https://www.pixar.com/
